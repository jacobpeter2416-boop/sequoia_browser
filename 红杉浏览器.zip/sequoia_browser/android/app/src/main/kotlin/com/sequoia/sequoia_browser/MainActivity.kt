package com.sequoia.sequoia_browser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
